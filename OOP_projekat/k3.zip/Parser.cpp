#include "Parser.h"
#include "NullArgumentCmd.h"
#include "Touch.h"
#include "Echo.h"
#include "Wc.h"
#include "Prompt.h"
#include "Truncate.h"
#include "Rm.h"
#include "Tr.h"
#include "Head.h"
#include "Batch.h"
#include "Pipeline.h"

Command* Parser::parseCommand(string line){
    vector<Token> tokens = tokenize(line);

    if (containsPipe(tokens)) return parsePipeline(tokens);

    return parseTokens(tokens);
}

Command* Parser::parseTokens(const vector<Token>& tokens)
{
    if (tokens.empty())
        return nullptr;

    Token cmd = tokens[0];
    if (cmd.kind != TokenType::Word) {}// GRESKA
    string cmd_name = cmd.value;

    if (cmd_name == "time" || cmd_name == "date") {
        return parseNullArgumentCmd(tokens);
    }

    if (cmd_name == "touch" || cmd_name == "prompt" ||
        cmd_name == "truncate" || cmd_name == "rm" || cmd_name == "batch") {
        return parseArgumentCmd(tokens);
    }

    if (cmd_name == "echo" || cmd_name == "wc" ||
        cmd_name == "tr" || cmd_name == "head") {
        return parseOptionalArgumentCmd(tokens);
    }
}

Command* Parser::parsePipeline(const vector<Token>& tokens){

    vector<vector<Token>> segments = extractPipelineSegments(tokens);

    PipelinePosition pos;
    for (int i = 0; i < segments.size(); i++) {
        if (i == 0) pos = PipelinePosition::START;
        else if (i == segments.size() - 1) pos = PipelinePosition::END;
        else pos = PipelinePosition::MIDDLE;

        validatePipelineSegment(segments[i], pos);
    }

    vector<Command*> commands;
    for (auto tokens : segments) {
        Command* cmd = parseTokens(tokens);
        commands.push_back(cmd);
    }

    return new Pipeline(commands);


    return nullptr;
    
}

vector<vector<Token>> Parser::extractPipelineSegments(const vector<Token>& tokens) {
    vector<vector<Token>> segments;
    vector<Token> current;

    for (auto t : tokens) {
        if (t.kind == TokenType::Pipe) {
            segments.push_back(current);
            current.clear();
        }
        else {
            current.push_back(t);
        }

    }
    segments.push_back(current);

    return segments;
}

void Parser::validatePipelineSegment(const vector<Token>& segment, PipelinePosition position){

    if (segment.empty() || segment[0].kind != TokenType::Word) { } //GRESKA

    string cmd = segment[0].value;

    // Komanda bez ulaza mora biti na pocetku
    if ((cmd == "time" || cmd == "date") && position != PipelinePosition::START){ } //GRESKA 
    if (cmd == "touch" || cmd == "rm" || cmd == "truncate" || cmd == "prompt" || cmd == "batch") {} // GRESKA


    for (int i = 1; i < segment.size(); i++) {
        Token t = segment[i];

        if (position == PipelinePosition::START || position == PipelinePosition::MIDDLE) {
            if (t.kind == TokenType::RedirectOutput || t.kind == TokenType::DoubleRedirectOutput) {} //GRESKA
        }
        else if (position == PipelinePosition::END || position == PipelinePosition::MIDDLE) {
            if(t.kind == TokenType::RedirectInput) {} //GRESKA

            if ((t.kind == TokenType::QuotedString || t.kind == TokenType::Word) && (i == 1 || i == 2))
            {
                //GRESKA
                //Ako je na poziciji 2 ili 3 i u pitanju je jedan od dva tipa (dodatno proveriti da slucajno nije opcija) 
                //onda je u pitanju argument
            }
        }
    }
}




Command* Parser::parseNullArgumentCmd(const vector<Token>& tokens)
{
    if(tokens.size() != 1) { } // GRESKA

    string cmd_name = tokens[0].value;
    Stream* stream = Stream::createStream(tokens, 1, defaultOutput, "timedate");

    if (cmd_name == "time") {
        return new Time(stream);
    }
    if (cmd_name == "date") {
        return new Date(stream);
    }
}

Command* Parser::parseArgumentCmd(const vector<Token>& tokens){
    // da li je dobar uslov za gresku?
    if(tokens.size() != 2) { } // GRESKA

    string cmd_name = tokens[0].value;
    string argument = tokens[1].value;

    if (cmd_name == "touch") {
        return new Touch(argument);
    }
    if (cmd_name == "prompt") {
        return new Prompt(argument);
    }
    if (cmd_name == "truncate") {
        return new Truncate(argument);
    }
    if (cmd_name == "rm") {
        return new Rm(argument);
    }
    if (cmd_name == "batch") {
        return makeBatch(tokens);
    }

    return nullptr;
}

Command* Parser::parseOptionalArgumentCmd(const vector<Token>& tokens)
{
    string cmd_name = tokens[0].value;

    if (cmd_name == "echo") {
        return makeEcho(tokens);
    }
    if (cmd_name == "wc") {
        return makeWc(tokens);
    }
    if (cmd_name == "tr") {
        return makeTr(tokens);
    }
    if (cmd_name == "head") {
        return makeHead(tokens);
    }

}

Command* Parser::makeEcho(const vector<Token>& tokens){
    int i = 1;

    Token argument = getArgument(tokens, i);

    Stream* stream = Stream::createStream(tokens, i, argument, defaultOutput, "echo");
    return new Echo(stream);
}


Command* Parser::makeWc(const vector<Token>& tokens){
    int i = 1;

    if (i >= tokens.size() || tokens[i].kind != TokenType::Option) { } //GRESKA
    Token option = tokens[i];
    i++;

    Token argument = getArgument(tokens, i);

    Stream* stream = Stream::createStream(tokens, i, argument, defaultOutput, "wc");

    // -w ili -c
    if (option.value == "w")
        return new WcWord(stream);
    if (option.value == "c")
        return new WcCharacter(stream);
   

    return nullptr;
}

Command* Parser::makeTr(const vector<Token>& tokens){
    string what = "", with = "";
    int i = 1;

    Token argument = getArgument(tokens, i);

    if (i >= tokens.size() || tokens[i].kind != TokenType::Option) {} //GRESKA
    what = tokens[i].value;
    i++;

    if (i < tokens.size() && tokens[i].kind == TokenType::Word) with = tokens[i].value;

    Stream* stream = Stream::createStream(tokens, i, argument, defaultOutput, "tr");

    return new Tr(stream, what, with);
}

Command* Parser::makeHead(const vector<Token>& tokens){
    int i = 1;

    if (i >= tokens.size() || tokens[i].kind != TokenType::Option) {} //GRESKA
    Token ncount = tokens[i];
    i++;
    int count;
    if (!validateCount(ncount.value, count)) { } //GRESKA

    Token argument = getArgument(tokens, i);

    Stream* stream = Stream::createStream(tokens, i, argument, defaultOutput, "tr");

    return new Head(stream, count);
}

Command* Parser::makeBatch(const vector<Token>& tokens){
    if(tokens.size() > 4) { } //GRESKA

    string argument = tokens[1].value;
    if (tokens.size() == 2) return new Batch(argument, this);

    if(tokens[2].kind != TokenType::RedirectOutput && tokens[2].kind != TokenType::DoubleRedirectOutput) { } //GRESKA

    if(tokens.size() < 4 || tokens[3].kind != TokenType::Word) { } //GRESKA

    return new Batch(argument, tokens[3].value, this);
}


//------------------------------------------------------------------------------------------------------------------------------------

vector<Token> Parser::tokenize(string line) {
    int i = 0;
    vector<Token> tokens;

    while (i < line.size()) {

        if (isspace(line[i])) {
            i++;
            continue;
        }
        else if (line[i] == '"')
        {
            tokens.push_back(
                Token(TokenType::QuotedString, readQuoted(line, i))
            );
        }
        else if(line[i] == '-') {
            tokens.push_back(
                Token(TokenType::Option, readWord(line, ++i))
            );
        }
        else if (line[i] == '<') {
            tokens.push_back(
                Token(TokenType::RedirectInput)
            );
        }
        else if (line[i] == '>' && i + 1 < line.size() && line[i + 1] == '>') {
            i++;
            tokens.push_back(
                Token(TokenType::DoubleRedirectOutput)
            );
        }
        else if (line[i] == '>') {
            tokens.push_back(
                Token(TokenType::RedirectOutput)
            );
        }
        else if (line[i] == '|') {
            tokens.push_back(
                Token(TokenType::Pipe)
            );
        }
        else {
            tokens.push_back(
                Token(TokenType::Word, readWord(line, i))
            );
        }

        i++;
    }

    return tokens;
}

//obe pomocne funkcije ulaze sa i koji oznacava prvi detektovan karakter
string Parser::readQuoted(const string& line, int& i)
{
    if (i == line.size() - 1) {} // GRESKA

    string quoted;
    i++;
    while (line[i] != '"') {
        quoted.push_back(line[i]);
        i++;

        if (i > line.size() - 1) {} //GRESKA
    }

    return quoted;
}

string Parser::readWord(const string& line, int& i)
{
    if( i == line.size()) { } // GRESKA nesto nedostaje

    while (isspace(line[i])) {
        i++;
        if( i == line.size()){ } // GRESKA
    }

    string word;
    while (!isspace(line[i])) {
        word.push_back(line[i]);

        if (i == line.size() - 1) break;

        i++;
    }
    return word;
}
